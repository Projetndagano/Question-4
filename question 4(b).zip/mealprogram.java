/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bd.questionfour;

/**
 *
 * @author PROJET NDAGANO
 */
public class mealprogram {
   public static void main(String[] args) {
        double porridge = 2;
        double milk = 2; 
        double cupSize = 0.5;
        int porridgeInterval = 45; // in minutes
        int milkInterval = 30; // in minutes
// after declaring, we have to generate some formula to calculate the total porridge quantity of feeding
        int porridgeFeed = (int) (porridge / cupSize);
        int milkFeeds = (int) (milk / cupSize);
// let's generate the formula to calculate the time of feeding the baby
        int totalPorridgeTime = porridgeFeed * porridgeInterval;
        int totalMilkTime = milkFeeds * milkInterval;
// let's combine both time for porridge and time for milk
        int totalTime = totalPorridgeTime + totalMilkTime;

        System.out.println("Total time to finish both porridge and milk: " + totalTime + " minutes");
    }
}


